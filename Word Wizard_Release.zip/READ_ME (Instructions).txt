Thank you for downloading Word Wizard!

To launch, keep the .dll, .exe, and .pck files in the same folder and run Word Wizard.exe.